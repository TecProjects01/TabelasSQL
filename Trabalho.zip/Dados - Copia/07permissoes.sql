REVOKE ALL ON alunos FROM PUBLIC;
REVOKE ALL ON matriculas FROM PUBLIC;
REVOKE ALL ON pagamentos FROM PUBLIC;


GRANT USAGE ON SCHEMA academico TO academico_user;
GRANT SELECT ON ALL TABLES IN SCHEMA academico TO academico_user;


GRANT USAGE ON SCHEMA financeiro TO financeiro_user;
GRANT SELECT ON ALL TABLES IN SCHEMA financeiro TO financeiro_user;


GRANT USAGE ON SCHEMA suporte TO suporte_user;
GRANT SELECT ON ALL TABLES IN SCHEMA suporte TO suporte_user;


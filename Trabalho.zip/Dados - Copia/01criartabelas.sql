-- Passo 1 — Criar Tabelas:
CREATE TABLE alunos (
id_aluno SERIAL PRIMARY KEY,
nome TEXT NOT NULL,
email TEXT NOT NULL,
telefone TEXT,
cpf TEXT
);

CREATE TABLE matriculas (
id_matricula SERIAL PRIMARY KEY,
id_aluno INT NOT NULL REFERENCES alunos(id_aluno),
curso TEXT NOT NULL,
nota NUMERIC(4,2)
);

CREATE TABLE pagamentos (
id_pagamento SERIAL PRIMARY KEY,
id_aluno INT NOT NULL REFERENCES alunos(id_aluno),
valor NUMERIC(10,2),
data_pagamento DATE
);
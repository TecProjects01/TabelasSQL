-- Passo 4 — Criar Usuários:
CREATE USER academico_user WITH PASSWORD 'academico123';
CREATE USER financeiro_user WITH PASSWORD 'financeiro123';
CREATE USER suporte_user WITH PASSWORD 'suporte123';
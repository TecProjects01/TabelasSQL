-- Passo 2 — Inserir Dados de Exemplo:
INSERT INTO alunos (nome, email, telefone, cpf) VALUES
('Ana Silva', 'ana.silva@email.com', '199999999', '111.111.111-11'),
('Bruno Souza', 'bruno.souza@email.com', '199888888', '222.222.222-22'),
('Carla Oliveira', 'carla.oliveira@email.com', '199777777', '333.333.333-33'),
('Diego Santos', 'diego.santos@email.com', '199666666', '444.444.444-44');

INSERT INTO matriculas (id_aluno, curso, nota) VALUES
(1, 'ADS', 8.5),
(2, 'ADS', 7.2),
(3, 'ADS', 9.1),
(4, 'ADS', 6.8);

INSERT INTO pagamentos (id_aluno, valor, data_pagamento) VALUES
(1, 300.00, '2023-07-10'),
(2, 200.00, '2025-04-23'),
(3, 500.00, '2022-01-29'),
(4, 800.00, '2024-02-29'); 

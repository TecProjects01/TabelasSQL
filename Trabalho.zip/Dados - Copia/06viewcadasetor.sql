-- Passo 6 — Criar Views para Cada Setor
CREATE SCHEMA academico;
CREATE SCHEMA financeiro;
CREATE SCHEMA suporte;

-- View Acadêmico
CREATE VIEW academico.alunos AS
SELECT
b.id_aluno,
b.nome,
m.curso,
m.nota
FROM base_alunos b
JOIN matriculas m ON b.id_aluno = m.id_aluno;

-- View Financeiro
CREATE VIEW financeiro.alunos AS
SELECT
b.id_aluno,
b.nome,
p.valor,
p.valor * 0.1,
p.data_pagamento
FROM base_alunos b
JOIN pagamentos p ON b.id_aluno = p.id_aluno;

-- View Suporte
CREATE VIEW suporte.alunos AS
SELECT
id_aluno,
nome,
email,
telefone
FROM base_alunos;
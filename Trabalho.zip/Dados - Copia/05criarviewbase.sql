-- Passo 5 — Criar View Base (Evita Repetição)
CREATE VIEW base_alunos AS
SELECT
id_aluno,
nome,
email,
telefone,
cpf
FROM alunos;
SET ROLE academico_user;

SELECT * FROM academico.alunos;
SELECT * FROM alunos;          
SELECT * FROM financeiro.alunos;
SELECT * FROM suporte.alunos;

---------------------------------

SET ROLE financeiro_user;

SELECT * FROM financeiro.alunos;
SELECT * FROM alunos;   
SELECT * FROM academico.alunos;
SELECT * FROM suporte.alunos;

---------------------------------

SET ROLE suporte_user;

SELECT * FROM suporte.alunos;
SELECT * FROM alunos;  
SELECT * FROM financeiro.alunos;
SELECT * FROM academico.alunos;

